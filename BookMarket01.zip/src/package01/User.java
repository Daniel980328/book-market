package package01;

public class User extends Person {

	public User(String pname, String pphone) {
		super(pname, pphone);
		
	}

}
