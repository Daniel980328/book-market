package package01;

import java.util.Scanner;

public class welcome {
	private static String[][] mBook;
	private static CartItem[] cartItemList = new CartItem[3];
	private static int cartcount= 0;
	
	public static void menuIntroduction() {
		System.out.println("*****************************************");
		System.out.println("\tWelcome to Shopping mall");
		System.out.println("\tWelcome to Book Market!");
		System.out.println("*****************************************");
		System.out.println("1. 고객정보확인하기\t\t4. 바구니에 항목추가하기");
		System.out.println("2. 장바구니 상품 목록 보기\t5. 장바구니에 항목 수량 줄이기");
		System.out.println("3. 장바구니 비우기\t\t6. 장바구니의 항목 삭제하기");
		System.out.println("7. 영수증 표시하기\t\t8. 종료");
		System.out.println("*****************************************");
	}
	
	public static void menuGuestInfo() {
		System.out.println("현재 고객 정보 :");
		System.out.println("이름:"+user.getName()+"   "+"연락처:"+user.getPhone());
	}
	public static void menuCartItemList() {
		System.out.println("장바구니 상품 목록 보기");
	}
	public static void menuCartClear() {
		System.out.println("장바구니 비우기");
	}
	public static void menuCartAddItem() {
		System.out.println("바구니에 항목추가하기");
		String[][] mBook = BookList();
		
		while(true) {
			System.out.println("장바구니에 추가할 도서의 ID를 입력하세요 :");
			Scanner input = new Scanner(System.in);
			String str = input.nextLine();
			
			int search_index =-1;
			
			for(int i=0; i<3;i++) {
				if(str.equals(mBook[i][0])) {
					search_index=i;
					break;
				}
			}
			
			if(search_index==-1) {
				System.out.println("도서의 ID를 확인해 주세요.");
				continue;
			}
			
			System.out.println("장바구니에 추가하겠습니까? (Y|N)");
			String yn = input.nextLine();
			
			if(yn.toLowerCase().equals("y")) {
				System.out.println(mBook[search_index][1] + " 도서가 장바구니에 추가되었습니다.");
			}
			break;
		}
	}
	public static void menuCartRemoveItemCount() {
		System.out.println("장바구니에 항목 수량 줄이기");
	}
	public static void menuCartRemoveItem() {
		System.out.println("장바구니의 항목 삭제하기");
	}
	public static void menuCartBill() {
		System.out.println("영수증 표시하기");
	}
	public void menuExit() {
		
	}
	public static String[][] BookList() {
//		mBook배열 만들기
		String[][] mBook = new String[][]
				{ {"ISBN1234","쉽게 배우는 JSP 웹 프로그래밍","27000",
					"송미영","단계별로 쇼핑몰을 구현하며 배우는 JSP 웹 프로그래밍",
					"IT전문서","2018/10/08"},
				  {"ISBN1235","안드로이드 프로그래밍","33000","우재남",
				   "십습 단계별 명쾌한 멘토링!","IT전문서","2022/01/22"},
				  {"ISBN1236","스크래치","22000","고광일",
				   "컴퓨팅 사고력을 키우는 블록 코딩","컴퓨터입문","2019/06/10"}};
		for(int i=0;i<3;i++) {
			for(int j=0;j<7;j++) {
				System.out.print(mBook[i][j] + " | ");
			}
			System.out.println("");
		}
		
		return mBook;
	}
	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		
		System.out.print("당신의 이름을 입력하세요 : ");
		String name= input.next();
		
		System.out.print("연락처를 입력하세요 : ");
		String phone= input.next();
		
		user= new Person(name,phone);
		
		boolean end_flag=false;
		
		while(true){
			menuIntroduction();
			
			System.out.print("메뉴번호를 선택해 주세요 : ");
			int number=input.nextInt();
			
			if(number<1 || number>8) {
				System.out.println("메뉴번호가 틀렸습니다.다시 선택해 주세요..");
				continue;
			}
			
			switch(number) {
			case 1:
				menuGuestInfo();
				break;
			case 2:
				menuCartItemList();
				break;
			case 3:
				menuCartClear();
				break;
			case 4:
				menuCartAddItem();
				break;
			case 5:
				menuCartRemoveItemCount();
				break;
			case 6:
				menuCartRemoveItem();
				break;
			case 7:
				menuCartBill();
				break;
			case 8:
				end_flag=true;
				break;
			default:				
			}
			
			if(end_flag){
				break;
			}			
		}
		
		System.out.println("Book maket 종료");
		
	}
}
