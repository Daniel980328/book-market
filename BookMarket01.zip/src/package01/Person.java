package package01;

public class Person {
	private String name;
	private String phone;
	
	Person(){
	}
	
	Person(String pname,String pphone){
		this.name = pname;
		this.phone = pphone;
	}
	
	String getName() {
		return name;
	}
	
	String getPhone() {
		return phone;
	}
	
	void setName(String pname) {
		this.name = pname;
	}
	
	void setPhone(String pphone) {
		this.phone = pphone;
	}
}
